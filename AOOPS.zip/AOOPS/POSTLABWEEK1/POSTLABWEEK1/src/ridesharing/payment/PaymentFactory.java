package ridesharing.payment;

public class PaymentFactory {
    public static PaymentMethod getPaymentMethod(String type) {
        switch (type.toLowerCase()) {
            case "creditcard":
                return new CreditCard();
            case "paypal":
                return new PayPal();
            case "cash":
                return new Cash();
            default:
                throw new IllegalArgumentException("Invalid payment method!");
        }
    }
}
