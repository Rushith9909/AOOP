package ridesharing;

import ridesharing.vehicles.Vehicle;
import ridesharing.vehicles.VehicleFactory;
import ridesharing.payment.PaymentFactory;
import ridesharing.payment.PaymentMethod;
import ridesharing.auth.UserAuthentication;

public class Main {
    public static void main(String[] args) {
        // Authenticate User
    	UserAuthentication authManager = UserAuthentication.getInstance();
        authManager.login("JohnDoe");

        // Select Vehicle and Book Ride
        Vehicle vehicle = VehicleFactory.getVehicle("car");
        vehicle.bookRide();

        // Choose Payment Method and Pay
        PaymentMethod paymentMethod = PaymentFactory.getPaymentMethod("creditcard");
        paymentMethod.pay(50.0);

        // Logout User
        authManager.logout();
    }
}
