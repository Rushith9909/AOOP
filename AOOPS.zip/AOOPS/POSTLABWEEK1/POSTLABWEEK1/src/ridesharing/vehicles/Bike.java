package ridesharing.vehicles;

public class Bike extends Vehicle {
    @Override
    public void bookRide() {
        System.out.println("Bike ride booked!");
    }
}
