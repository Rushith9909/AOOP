package generics;

public class Main {
    public static void main(String[] args) {
        // Integer array
        Integer[] intArray = {10, 5, 20, 15, 25};
        ArrayProcessor<Integer> intProcessor = new ArrayProcessor<>();
        System.out.println("Integer - Max: " + intProcessor.findMax(intArray));
        System.out.println("Integer - Min: " + intProcessor.findMin(intArray));

        // String array
        String[] strArray = {"Apple", "Banana", "Peach", "Grapes"};
        ArrayProcessor<String> strProcessor = new ArrayProcessor<>();
        System.out.println("String - Max: " + strProcessor.findMax(strArray));
        System.out.println("String - Min: " + strProcessor.findMin(strArray));

        // Character array
        Character[] charArray = {'A', 'Z', 'M', 'B'};
        ArrayProcessor<Character> charProcessor = new ArrayProcessor<>();
        System.out.println("Character - Max: " + charProcessor.findMax(charArray));
        System.out.println("Character - Min: " + charProcessor.findMin(charArray));

        // Float array
        Float[] floatArray = {10.5f, 3.2f, 7.8f, 2.5f};
        ArrayProcessor<Float> floatProcessor = new ArrayProcessor<>();
        System.out.println("Float - Max: " + floatProcessor.findMax(floatArray));
        System.out.println("Float - Min: " + floatProcessor.findMin(floatArray));
    }
}
