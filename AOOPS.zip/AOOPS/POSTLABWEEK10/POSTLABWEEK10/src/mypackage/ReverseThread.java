package mypackage;

class ReverseThread extends Thread {
    @Override
    public void run() {
        System.out.println("Numbers in Reverse Order:");
        for (int i = 10; i >= 1; i--) {
            System.out.print(i + " ");
        }
        System.out.println();
    }
}