package auction;

import java.util.ArrayList;
import java.util.List;

public class Auctioneer {
    private List<Bidder> bidders = new ArrayList<>();

    public void subscribe(Bidder bidder) {
        bidders.add(bidder);
    }

    public void unsubscribe(Bidder bidder) {
        bidders.remove(bidder);
    }

    public void notifyBidders(String message) {
        for (Bidder bidder : bidders) {
            bidder.update(message);
        }
    }
}