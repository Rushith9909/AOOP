/**
 * 
 */
/**
 * 
 */
module SKILL_TASK_5 {
}