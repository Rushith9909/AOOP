package repositories;

import models.Student;
import java.util.HashMap;
import java.util.Map;

public class StudentRepository {
    private Map<Integer, Student> studentDatabase = new HashMap<>();

    public void saveStudent(Student student) {
        studentDatabase.put(student.getId(), student);
    }

    public Student findStudentById(int id) {
        return studentDatabase.get(id);
    }
}
	