package main;

import models.GraduateStudent;
import models.UndergraduateStudent;
import services.StudentService;

public class SISMain {
    public static void main(String[] args) {
        StudentService studentService = new StudentService();

        UndergraduateStudent ugStudent = new UndergraduateStudent(1, "Alice", "CSE", 3);
        GraduateStudent gradStudent = new GraduateStudent(2, "Bob", "ECE", "AI Research");

        studentService.addStudent(ugStudent);
        studentService.addStudent(gradStudent);

        System.out.println("Student Records:");
        studentService.getAllStudents().forEach(Student::displayInfo);
    }
}
