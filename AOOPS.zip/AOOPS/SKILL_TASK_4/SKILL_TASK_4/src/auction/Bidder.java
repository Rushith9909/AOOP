package auction;

public class Bidder implements Observer {
    private String name;

    public Bidder(String name) {
        this.name = name;
    }

    @Override
    public void update(String item, double bidAmount) {
        System.out.println(name + " has been notified: New bid on " + item + " - $" + bidAmount);
    }
}
