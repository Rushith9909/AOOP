package auction;

import java.util.Scanner;

public class LiveAuction extends Auction {
    private Auctioneer auctioneer;

    public LiveAuction(Auctioneer auctioneer) {
        this.auctioneer = auctioneer;
    }

    @Override
    protected void initializeAuction() {
        System.out.println("Auction for " + auctioneer + " is starting!");
    }

    @Override
    protected void acceptBids() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter bid amounts (0 to stop):");
        while (true) {
            double bid = scanner.nextDouble();
            if (bid == 0) break;
            auctioneer.placeBid(bid);
        }
        scanner.close();
    }

    @Override
    protected void concludeAuction() {
        System.out.println("Auction concluded! Highest bid: $" + auctioneer.getHighestBid());
    }
}
