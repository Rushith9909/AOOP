import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CadetSorterTest {

    @Test
    void testEmptyList() {
        List<String> cadets = new ArrayList<>();
        assertTrue(CadetSorter.isSortedAlphabetically(cadets), "An empty list should be considered sorted.");
    }

    @Test
    void testSingleCadet() {
        List<String> cadets = List.of("John");
        assertTrue(CadetSorter.isSortedAlphabetically(cadets), "A single cadet should be considered sorted.");
    }

    @Test
    void testMultipleCadetsSorted() {
        List<String> cadets = Arrays.asList("Alice", "Bob", "Charlie", "David");
        assertTrue(CadetSorter.isSortedAlphabetically(cadets), "The list is already sorted alphabetically.");
    }

    @Test
    void testMultipleCadetsUnsorted() {
        List<String> cadets = Arrays.asList("Charlie", "Alice", "Bob", "David");
        assertFalse(CadetSorter.isSortedAlphabetically(cadets), "The list is not sorted alphabetically.");
    }

    @Test
    void testCadetsWithIdenticalNames() {
        List<String> cadets = Arrays.asList("Alice", "Alice", "Bob", "Bob");
        assertTrue(CadetSorter.isSortedAlphabetically(cadets), "The list with identical names is sorted alphabetically.");
    }

    @Test
    void testCadetsMixedCase() {
        List<String> cadets = Arrays.asList("alice", "Bob", "Charlie", "david");
        assertFalse(CadetSorter.isSortedAlphabetically(cadets), "The list is case-sensitive and not sorted alphabetically.");
    }
}
