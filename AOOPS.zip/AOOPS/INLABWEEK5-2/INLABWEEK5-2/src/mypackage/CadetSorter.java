package mypackage;

import java.util.List;

public class CadetSorter {
    public static boolean isSortedAlphabetically(List<String> cadetNames) {
        for (int i = 1; i < cadetNames.size(); i++) {
            if (cadetNames.get(i - 1).compareTo(cadetNames.get(i)) > 0) {
                return false;
            }
        }
        return true;
    }
}
