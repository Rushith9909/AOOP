import sis.model.Student;
import sis.model.Course;
import sis.services.EnrollmentService;

public class Main {
    public static void main(String[] args) {
        Student student1 = new Student(1, "Alice");
        Student student2 = new Student(2, "Bob");

        Course course1 = new Course(101, "Mathematics");
        Course course2 = new Course(102, "Computer Science");

        EnrollmentService enrollmentService = new EnrollmentService();

        enrollmentService.enrollStudentInCourse(student1, course1);
        enrollmentService.enrollStudentInCourse(student2, course2);
        enrollmentService.enrollStudentInCourse(student1, course2);

        System.out.println("\nStudent Details:");
        System.out.println(student1);
        System.out.println(student2);

        System.out.println("\nCourse Details:");
        System.out.println(course1);
        System.out.println(course2);
    }
}
