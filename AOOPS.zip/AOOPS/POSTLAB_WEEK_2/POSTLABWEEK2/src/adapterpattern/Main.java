package adapterpattern;

public class Main {
    public static void main(String[] args) {
        GalleryApp galleryApp = new GalleryApp();

        galleryApp.show("png", "image1.png");

        galleryApp.show("jpg", "image2.jpg");

        galleryApp.show("gif", "image3.gif");
    }
}