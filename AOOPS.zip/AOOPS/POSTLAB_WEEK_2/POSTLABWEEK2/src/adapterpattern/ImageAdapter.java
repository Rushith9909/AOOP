package adapterpattern;

public class ImageAdapter implements ImageViewer {
    private AdvancedImageViewer advancedImageViewer;

    public ImageAdapter(String fileType) {
        if (fileType.equalsIgnoreCase("png")) {
            advancedImageViewer = new PngShower();
        } else if (fileType.equalsIgnoreCase("jpg")) {
            advancedImageViewer = new JpgShower();
        }
    }

    @Override
    public void show(String fileType, String fileName) {
        if (fileType.equalsIgnoreCase("png")) {
            advancedImageViewer.showPng(fileName);
        } else if (fileType.equalsIgnoreCase("jpg")) {
            advancedImageViewer.showJpg(fileName);
        }
    }
}
