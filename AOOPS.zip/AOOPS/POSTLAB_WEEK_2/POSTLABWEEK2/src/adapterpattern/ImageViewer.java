package adapterpattern;

public interface ImageViewer {
    void show(String fileType, String fileName);
}
