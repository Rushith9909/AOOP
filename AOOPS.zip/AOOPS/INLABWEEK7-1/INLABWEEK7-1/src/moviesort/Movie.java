package moviesort;

public class Movie implements Comparable<Movie> {
    private String name;
    private double rating;
    private int year;

    // Constructor
    public Movie(String name, double rating, int year) {
        this.name = name;
        this.rating = rating;
        this.year = year;
    }

    // Getters
    public String getName() {
        return name;
    }

    public double getRating() {
        return rating;
    }

    public int getYear() {
        return year;
    }

    // compareTo method to sort by year
    @Override
    public int compareTo(Movie other) {
        return Integer.compare(this.year, other.year);
    }

    // toString method for displaying movie details
    @Override
    public String toString() {
        return name + " (" + year + ") - Rating: " + rating;
    }
}
