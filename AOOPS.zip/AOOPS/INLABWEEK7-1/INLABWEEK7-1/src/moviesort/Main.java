package moviesort;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Creating a list of movies
        List<Movie> movies = new ArrayList<>();
        movies.add(new Movie("Inception", 8.8, 2010));
        movies.add(new Movie("The Dark Knight", 9.0, 2008));
        movies.add(new Movie("Interstellar", 8.6, 2014));
        movies.add(new Movie("The Prestige", 8.5, 2006));
        movies.add(new Movie("Memento", 8.4, 2000));

        // Before Sorting
        System.out.println("Movies Before Sorting:");
        for (Movie movie : movies) {
            System.out.println(movie);
        }

        // Sorting the movies based on release year
        Collections.sort(movies);

        // After Sorting
        System.out.println("\nMovies After Sorting by Year:");
        for (Movie movie : movies) {
            System.out.println(movie);
        }
    }
}
