package main;

import models.Employee;
import java.util.*;

public class EmployeeStreamMain {
    public static void main(String[] args) {
        // List of 10 Employees
        List<Employee> employees = Arrays.asList(
            new Employee(1, "Alice", 65000),
            new Employee(2, "Bob", 80000),
            new Employee(3, "Charlie", 90000),
            new Employee(4, "David", 55000),
            new Employee(5, "Eve", 70000),
            new Employee(6, "Frank", 75000),
            new Employee(7, "Grace", 68000),
            new Employee(8, "Hank", 95000),
            new Employee(9, "Ivy", 72000),
            new Employee(10, "Jack", 85000)
        );

       
        System.out.println("\nEmployees earning above $70,000:");
        employees.stream()
                 .filter(emp -> emp.getSalary() > 70000)
                 .forEach(System.out::println);

       
        System.out.println("\nEmployees sorted by salary (Ascending):");
        employees.stream()
                 .sorted(Comparator.comparingDouble(Employee::getSalary))
                 .forEach(System.out::println);

        
        System.out.println("\nEmployees sorted by salary (Descending):");
        employees.stream()
                 .sorted(Comparator.comparingDouble(Employee::getSalary).reversed())
                 .forEach(System.out::println);

       
        Optional<Employee> highestSalaryEmployee = employees.stream()
                                                            .max(Comparator.comparingDouble(Employee::getSalary));
        highestSalaryEmployee.ifPresent(emp -> 
            System.out.println("\nHighest Salary Employee: " + emp));

       
        double averageSalary = employees.stream()
                                        .mapToDouble(Employee::getSalary)
                                        .average()
                                        .orElse(0.0);
        System.out.println("\nAverage Salary of Employees: $" + averageSalary);
    }
}
