package main;

import models.Employee;
import comparators.NameComparator;
import comparators.SalaryComparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class EmployeeSortingMain {
    public static void main(String[] args) {
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee(103, "Alice", 50000));
        employees.add(new Employee(101, "Charlie", 60000));
        employees.add(new Employee(102, "Bob", 45000));

        System.out.println("\n Original List:");
        printEmployees(employees);

        // Sorting by ID (Default Comparable)
        Collections.sort(employees);
        System.out.println("\n Sorted by ID:");
        printEmployees(employees);

        // Sorting by Name (Using Comparator)
        Collections.sort(employees, new NameComparator());
        System.out.println("\n Sorted by Name:");
        printEmployees(employees);

        // Sorting by Salary (Using Comparator)
        Collections.sort(employees, new SalaryComparator());
        System.out.println("\n Sorted by Salary:");
        printEmployees(employees);

        // Cloning an Employee
        Employee clone = employees.get(0).clone();
        System.out.println("\n Cloned Employee: " + clone);

        // Iterating using Iterator
        System.out.println("\n Iterating through Employees:");
        iterateEmployees(employees);
    }

    // Utility method to print employees
    private static void printEmployees(List<Employee> employees) {
        for (Employee e : employees) {
            System.out.println(e);
        }
    }

    // Iterating over employees using Iterator
    private static void iterateEmployees(List<Employee> employees) {
        Iterator<Employee> iterator = employees.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }
    }
}
