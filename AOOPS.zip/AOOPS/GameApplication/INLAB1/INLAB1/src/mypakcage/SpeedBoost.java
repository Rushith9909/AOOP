package mypakcage;

public class SpeedBoost implements PowerUp{
	public void activate() {
		System.out.println("Speed Boost is activated");
	}
}

