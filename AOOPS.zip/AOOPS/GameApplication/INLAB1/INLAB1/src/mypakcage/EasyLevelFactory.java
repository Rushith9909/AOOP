package mypakcage;

class EasyLevelFactory implements AbstaractFactory{
	public Weapon createWeapon() {
		return new Sword();
	}
	public PowerUp createPowerUp() {
		return new HealthBoost();
	}

}
