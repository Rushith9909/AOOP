package mypakcage;

class Gun implements Weapon {
	public void use() {
		System.out.println("Using Gun");
	}

}
