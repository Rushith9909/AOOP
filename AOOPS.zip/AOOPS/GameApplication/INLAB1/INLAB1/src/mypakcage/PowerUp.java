package mypakcage;

interface PowerUp {
	void activate();
}
