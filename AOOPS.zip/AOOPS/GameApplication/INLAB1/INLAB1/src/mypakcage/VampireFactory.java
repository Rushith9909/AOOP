package mypakcage;

class VampireFactory extends EnemyFactory{
	public Enemy createEnemy() {
		return new vampire();
	}
}

