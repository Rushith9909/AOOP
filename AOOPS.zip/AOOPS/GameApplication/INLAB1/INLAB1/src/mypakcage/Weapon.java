package mypakcage;

interface Weapon {
	void use();
}


