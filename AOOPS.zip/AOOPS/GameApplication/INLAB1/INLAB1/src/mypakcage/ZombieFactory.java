package mypakcage;

class ZombieFactory extends EnemyFactory {
    public Enemy createEnemy() {
        return new zombie();
    }
}