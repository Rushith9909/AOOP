package mypakcage;

class Sword implements Weapon{
	public void use() {
		System.out.println("Using Sword");
	}
}


