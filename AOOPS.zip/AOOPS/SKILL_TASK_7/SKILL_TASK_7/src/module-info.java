/**
 * 
 */
/**
 * 
 */
module SKILL_TASK_7 {
}