package main;

import models.Contact;
import services.ContactManager;

import java.util.Scanner;

public class ContactManagementMain {
    public static void main(String[] args) {
        ContactManager contactManager = new ContactManager();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n Contact Management System");
            System.out.println("1. Add Contact");
            System.out.println("2. Remove Contact");
            System.out.println("3. Search Contact");
            System.out.println("4. Display Contacts");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Phone: ");
                    String phone = scanner.nextLine();
                    System.out.print("Enter Email: ");
                    String email = scanner.nextLine();

                    Contact newContact = new Contact(name, phone, email);
                    if (contactManager.addContact(newContact)) {
                        System.out.println(" Contact added successfully!");
                    } else {
                        System.out.println("Contact already exists!");
                    }
                    break;

                case 2:
                    System.out.print("Enter Name to remove: ");
                    String removeName = scanner.nextLine();
                    if (contactManager.removeContact(removeName)) {
                        System.out.println(" Contact removed successfully!");
                    } else {
                        System.out.println(" Contact not found!");
                    }
                    break;

                case 3:
                    System.out.print("Enter Name to search: ");
                    String searchName = scanner.nextLine();
                    Contact foundContact = contactManager.searchContact(searchName);
                    if (foundContact != null) {
                        System.out.println(" Found: " + foundContact);
                    } else {
                        System.out.println("Contact not found!");
                    }
                    break;

                case 4:
                    System.out.println("\n Contact List:");
                    contactManager.displayContacts();
                    break;

                case 5:
                    System.out.println(" Exiting Contact Management System. Goodbye!");
                    scanner.close();
                    System.exit(0);

                default:
                    System.out.println(" Invalid choice! Please select a valid option.");
            }
        }
    }
}
