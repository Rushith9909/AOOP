package mypackage;

public class BoundedBufferTest {
    public static void main(String[] args) {
        BoundedBuffer sharedBuffer = new BoundedBuffer();

        // Create producer and consumer threads
        Thread producerThread = new Thread(new Producer(sharedBuffer), "Producer");
        Thread consumerThread = new Thread(new Consumer(sharedBuffer), "Consumer");

        // Start threads
        producerThread.start();
        consumerThread.start();
    }
}
