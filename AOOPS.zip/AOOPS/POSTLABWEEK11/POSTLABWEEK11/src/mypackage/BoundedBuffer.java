package mypackage;

import java.util.LinkedList;
import java.util.Queue;

class BoundedBuffer {
    private Queue<Integer> buffer = new LinkedList<>();
    private final int MAX_CAPACITY = 10;

    // Synchronized method to add items to the buffer
    public synchronized void produce(int item) throws InterruptedException {
        while (buffer.size() == MAX_CAPACITY) {
            wait(); // Wait if buffer is full
        }
        buffer.add(item);
        System.out.println("Produced: " + item);
        notifyAll(); // Notify consumers
    }

    // Synchronized method to remove items from the buffer
    public synchronized int consume() throws InterruptedException {
        while (buffer.isEmpty()) {
            wait(); // Wait if buffer is empty
        }
        int item = buffer.poll();
        System.out.println("Consumed: " + item);
        notifyAll(); // Notify producers
        return item;
    }
}
