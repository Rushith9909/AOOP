package main;

import models.Employee;
import services.SalaryDistributor;
import java.util.*;

public class CoffeeShopMain {
    public static void main(String[] args) {
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee("Employee1", 30, 5, 3000));
        employees.add(new Employee("Employee2", 28, 4, 2800));
        employees.add(new Employee("Employee3", 26, 3, 2600));
        employees.add(new Employee("Employee4", 24, 1, 2400));
        employees.add(new Employee("Employee5", 22, 0, 2200));

        // Salary Distribution Process
        SalaryDistributor distributor = new SalaryDistributor(employees);
        distributor.distributeSalariesWithBonus();
        distributor.displayEmployees();
    }
}
