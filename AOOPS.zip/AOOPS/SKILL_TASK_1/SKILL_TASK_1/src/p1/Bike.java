package p1;

class Bike extends Vehicle {
   Bike() {
   }

   public void requestRide() {
      System.out.println("Bike ride requested!");
   }
}
