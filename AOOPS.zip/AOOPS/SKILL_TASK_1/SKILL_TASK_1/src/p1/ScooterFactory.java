package p1;

class ScooterFactory implements RideFactory {
   ScooterFactory() {
   }

   public Vehicle createVehicle() {
      return new Scooter();
   }
}
