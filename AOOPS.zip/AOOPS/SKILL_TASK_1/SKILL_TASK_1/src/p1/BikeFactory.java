package p1;

class BikeFactory implements RideFactory {
   BikeFactory() {
   }

   public Vehicle createVehicle() {
      return new Bike();
   }
}