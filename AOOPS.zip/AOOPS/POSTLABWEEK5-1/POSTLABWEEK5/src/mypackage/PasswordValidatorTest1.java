package mypackage;

import static org.junit.Assert.*;

import org.junit.Test;

public class PasswordValidatorTest1 {

	@Test
    public void testValidPassword() {
        PasswordValidator validator = new PasswordValidator();
        assertTrue(validator.isValidPassword("Abc123"));
    }

    @Test
    public void testPasswordTooShort() {
        PasswordValidator validator = new PasswordValidator();
        assertFalse(validator.isValidPassword("Abc12"));
    }

    @Test
    public void testPasswordTooLong() {
        PasswordValidator validator = new PasswordValidator();
        assertFalse(validator.isValidPassword("Abc123456789"));
    }

    @Test
    public void testEmptyPassword() {
        PasswordValidator validator = new PasswordValidator();
        assertFalse(validator.isValidPassword(""));
    }

}
