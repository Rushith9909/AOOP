public class PasswordValidator {

    public boolean isValidPassword(String password) {
        if (password == null) {
            return false;
        }
        int length = password.length();
        return length >= 5 && length <= 10;
    }
}
