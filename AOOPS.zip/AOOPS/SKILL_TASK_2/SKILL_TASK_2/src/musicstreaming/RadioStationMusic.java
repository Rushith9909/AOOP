package musicstreaming;

public class RadioStationMusic implements MusicSource {
    private String stationName;

    public RadioStationMusic(String stationName) {
        this.stationName = stationName;
    }

    @Override
    public void playMusic() {
        System.out.println("Tuning into radio station: " + stationName);
    }
}
