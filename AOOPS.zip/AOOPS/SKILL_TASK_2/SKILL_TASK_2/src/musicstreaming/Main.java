package musicstreaming;

public class Main {
    public static void main(String[] args) {
        MusicPlayerFacade player = new MusicPlayerFacade();

        System.out.println("Playing Local File:");
        player.playLocalMusic();

        System.out.println("\nPlaying Online Stream:");
        player.playOnlineMusic();

        System.out.println("\nPlaying Radio Station:");
        player.playRadio();

        System.out.println("\nEnhanced Playback with Equalizer and Volume Control:");
        player.playEnhancedOnlineMusic();
    }
}
