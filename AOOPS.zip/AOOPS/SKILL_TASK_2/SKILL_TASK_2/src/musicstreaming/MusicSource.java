package musicstreaming;

public interface MusicSource {
    void playMusic();
}
