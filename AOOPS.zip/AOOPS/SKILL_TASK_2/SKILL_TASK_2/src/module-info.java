/**
 * 
 */
/**
 * 
 */
module SKILL_TASK_2 {
}