package com.example.notifications;

public class SMSNotificationService extends NotificationService {
    @Override
    protected void prepareNotification(String user) {
        System.out.println("Preparing SMS notification for: " + user);
    }

    @Override
    protected void sendMessage(String user, String message) {
        System.out.println("Sending SMS to " + user + ": " + message);
    }
}
