package com.example.notifications;

public class NotificationSystem {
    public static void main(String[] args) {
        NotificationService emailService = new EmailNotificationService();
        NotificationService smsService = new SMSNotificationService();
        NotificationService pushService = new PushNotificationService();

        Notifier emailNotifier = new Notifier(emailService);
        Notifier smsNotifier = new Notifier(smsService);
        Notifier pushNotifier = new Notifier(pushService);

        UserEventManager eventManager = new UserEventManager();

        eventManager.addObserver(event -> {
            if ("UserRegistration".equals(event)) {
                emailNotifier.notifyUser("user@example.com", "Welcome to our service!");
            }
        });

        eventManager.addObserver(event -> {
            if ("PasswordReset".equals(event)) {
                smsNotifier.notifyUser("+123456789", "Your password reset code is 12345.");
            }
        });

        eventManager.addObserver(event -> {
            if ("NewMessage".equals(event)) {
                pushNotifier.notifyUser("user123", "You have a new message!");
            }
        });

        System.out.println("Triggering UserRegistration event:");
        eventManager.triggerEvent("UserRegistration");

        System.out.println("\nTriggering PasswordReset event:");
        eventManager.triggerEvent("PasswordReset");

        System.out.println("\nTriggering NewMessage event:");
        eventManager.triggerEvent("NewMessage");
    }
}
