package com.example.notifications;

public class Notifier {
    private final NotificationService notificationService;

    public Notifier(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    public void notifyUser(String user, String message) {
        notificationService.sendNotification(user, message);
    }
}
