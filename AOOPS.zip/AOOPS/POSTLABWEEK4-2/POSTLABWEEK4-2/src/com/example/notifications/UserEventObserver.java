package com.example.notifications;

public interface UserEventObserver {
    void onEvent(String event);
}
