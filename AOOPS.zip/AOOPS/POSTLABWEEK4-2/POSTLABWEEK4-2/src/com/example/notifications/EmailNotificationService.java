package com.example.notifications;

public class EmailNotificationService extends NotificationService {
    @Override
    protected void prepareNotification(String user) {
        System.out.println("Preparing email notification for: " + user);
    }

    @Override
    protected void sendMessage(String user, String message) {
        System.out.println("Sending email to " + user + ": " + message);
    }
}
