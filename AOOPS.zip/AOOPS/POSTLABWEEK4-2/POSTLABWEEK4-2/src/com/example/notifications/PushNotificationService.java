package com.example.notifications;

public class PushNotificationService extends NotificationService {
    @Override
    protected void prepareNotification(String user) {
        System.out.println("Preparing push notification for: " + user);
    }

    @Override
    protected void sendMessage(String user, String message) {
        System.out.println("Sending push notification to " + user + ": " + message);
    }
}
