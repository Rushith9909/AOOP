package bank;

public class Main {
    public static void main(String[] args) {
        Account account = new Account(101, 1000.0);

        Thread t1 = new Thread(new TransactionRunnable(account, 500, true), "Thread-Runnable-1");
        Thread t2 = new Thread(new TransactionRunnable(account, 200, false), "Thread-Runnable-2");

        Thread t3 = new TransactionThread(account, 300, true);
        t3.setName("Thread-Extends-1");
        Thread t4 = new TransactionThread(account, 400, false);
        t4.setName("Thread-Extends-2");

        t1.start();
        t2.start();
        t3.start();
        t4.start();

        try {
            t1.join();
            t2.join();
            t3.join();
            t4.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("\nFinal Account Balance: $" + account.getBalance());
    }
}