package models;

public class Employee {
    private String name;
    private int age;
    private String department;
    private double salary;

    public Employee(String name, int age, String department, double salary) {
        this.name = name;
        this.age = age;
        this.department = department;
        this.salary = salary;
    }
    public String getDepartment() {
        return department;
    }
    public double getSalary() {
        return salary;
    }
    public String getName() {
        return name;
    }
    @Override
    public String toString() {
        return name + " (Age: " + age + ", Department: " + department + ", Salary: $" + salary + ")";
    }
}