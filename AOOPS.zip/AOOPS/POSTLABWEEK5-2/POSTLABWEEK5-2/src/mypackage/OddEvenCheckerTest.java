package mypackage;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class OddEvenCheckerTest {
    @Test
    public void testEvenNumber() {
        OddEvenChecker checker = new OddEvenChecker();
        assertEquals("Even", checker.checkOddEven(4));
    }
    @Test
    public void testOddNumber() {
        OddEvenChecker checker = new OddEvenChecker();
        assertEquals("Odd", checker.checkOddEven(3));
    }
    @Test
    public void testZero() {
        OddEvenChecker checker = new OddEvenChecker();
        assertEquals("Even", checker.checkOddEven(0));
    }
    @Test
    public void testNegativeEvenNumber() {
        OddEvenChecker checker = new OddEvenChecker();
        assertEquals("Even", checker.checkOddEven(-6));
    }
    @Test
    public void testNegativeOddNumber() {
        OddEvenChecker checker = new OddEvenChecker();
        assertEquals("Odd", checker.checkOddEven(-5));
    }
}