package mypackage;

public class OddEvenChecker {
    public String checkOddEven(int number) {
        if (number % 2 == 0) {
            return "Even";
        } else {
            return "Odd";
        }
    }
}