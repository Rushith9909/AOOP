package main;

import models.ContactManager;
import java.util.Scanner;

public class ContactManagerMain {
    public static void main(String[] args) {
        ContactManager contactManager = new ContactManager();
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            System.out.println("\n--- Contact Manager ---");
            System.out.println("1. Add Contact");
            System.out.println("2. Get Contact");
            System.out.println("3. Remove Contact");
            System.out.println("4. Display Contacts");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline
            
            switch (choice) {
                case 1:
                    System.out.print("Enter Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Phone Number: ");
                    String phone = scanner.nextLine();
                    contactManager.addContact(name, phone);
                    break;

                case 2:
                    System.out.print("Enter Name: ");
                    String searchName = scanner.nextLine();
                    System.out.println("Phone Number: " + contactManager.getContact(searchName));
                    break;

                case 3:
                    System.out.print("Enter Name to Remove: ");
                    String removeName = scanner.nextLine();
                    contactManager.removeContact(removeName);
                    break;

                case 4:
                    contactManager.displayContacts();
                    break;

                case 5:
                    System.out.println("Exiting Contact Manager. Goodbye!");
                    scanner.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }
}
