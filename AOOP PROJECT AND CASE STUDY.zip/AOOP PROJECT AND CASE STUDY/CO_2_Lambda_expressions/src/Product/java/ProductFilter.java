package Product.java;
import java.util.List;
import java.util.stream.Collectors;

public class ProductFilter {
    public static List<Product> filterAvailableProducts(List<Product> products) {
        return products.stream()
                .filter(Product::isAvailable)  // Lambda expression for filtering
                .collect(Collectors.toList());
    }
}
