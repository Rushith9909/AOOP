package Product.java;
import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Product> products = Arrays.asList(
            new Product("Laptop", 1200.99, true),
            new Product("Phone", 799.49, false),
            new Product("Headphones", 150.75, true),
            new Product("Monitor", 299.99, true),
            new Product("Tablet", 450.00, false)
        );

        System.out.println("All Products:");
        products.forEach(System.out::println);

        List<Product> availableProducts = ProductFilter.filterAvailableProducts(products);

        System.out.println("\nAvailable Products:");
        availableProducts.forEach(System.out::println);
    }
}
