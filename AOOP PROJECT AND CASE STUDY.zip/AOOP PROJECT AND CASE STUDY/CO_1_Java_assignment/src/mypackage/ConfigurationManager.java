package mypackage;

import java.util.HashMap;
import java.util.Map;

public class ConfigurationManager {
    private static ConfigurationManager instance;
    private Map<String, String> configValues;

    // Private constructor to prevent instantiation
    private ConfigurationManager() {
        configValues = new HashMap<>();
    }

    // Public method to provide access to the instance
    public static ConfigurationManager getInstance() {
        if (instance == null) {
            instance = new ConfigurationManager();
        }
        return instance;
    }

    // Method to set a configuration value
    public void setConfig(String key, String value) {
        configValues.put(key, value);
    }

    // Method to get a configuration value
    public String getConfig(String key) {
        return configValues.getOrDefault(key, "Not Found");
    }

    // Method to remove a configuration
    public void removeConfig(String key) {
        configValues.remove(key);
    }

    // Method to check if a configuration exists
    public boolean hasConfig(String key) {
        return configValues.containsKey(key);
    }

    // Method to display all configurations
    public void displayAllConfigs() {
        System.out.println("Current Configurations:");
        for (Map.Entry<String, String> entry : configValues.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }
    }
}
