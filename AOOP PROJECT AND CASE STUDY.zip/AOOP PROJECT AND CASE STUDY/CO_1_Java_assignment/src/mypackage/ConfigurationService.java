package mypackage;

public class ConfigurationService {
    private ConfigurationManager configManager;

    public ConfigurationService() {
        this.configManager = ConfigurationManager.getInstance();
    }

    // Adds default configurations
    public void loadDefaultConfigurations() {
        configManager.setConfig("API_KEY", "API_KEY_12345");
        configManager.setConfig("MAX_CONNECTIONS", "100");
        configManager.setConfig("SERVER_URL", "https://example.com");
    }

    // Prints a specific configuration
    public void printConfig(String key) {
        System.out.println(key + ": " + configManager.getConfig(key));
    }

    // Removes a configuration
    public void removeConfig(String key) {
        configManager.removeConfig(key);
        System.out.println("Removed config: " + key);
    }

    // Displays all configurations
    public void displayAllConfigs() {
        configManager.displayAllConfigs();
    }
}
