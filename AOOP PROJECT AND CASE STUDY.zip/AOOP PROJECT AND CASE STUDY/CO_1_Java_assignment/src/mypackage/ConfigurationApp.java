package mypackage;

public class ConfigurationApp {
    public static void main(String[] args) {
        ConfigurationService configService = new ConfigurationService();

        // Load default configurations
        configService.loadDefaultConfigurations();

        // Retrieve and display configurations
        configService.printConfig("API_KEY");
        configService.printConfig("MAX_CONNECTIONS");

        // Remove a configuration
        configService.removeConfig("MAX_CONNECTIONS");

        // Display all remaining configurations
        configService.displayAllConfigs();
    }
}
