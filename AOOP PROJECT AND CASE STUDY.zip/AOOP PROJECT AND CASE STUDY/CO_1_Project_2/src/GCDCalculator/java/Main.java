package GCDCalculator.java;

//Main Class to test multiple instances of LCMCalculator
public class Main {
 public static void main(String[] args) {
     
     // First Instance
     LCMCalculator lcmCalc1 = new LCMCalculator();
     System.out.println("LCM of 12 and 18: " + lcmCalc1.lcm(12, 18));

     // Second Instance
     LCMCalculator lcmCalc2 = new LCMCalculator();
     System.out.println("LCM of 7 and 5: " + lcmCalc2.lcm(7, 5)); // Coprime numbers

     // Third Instance
     LCMCalculator lcmCalc3 = new LCMCalculator();
     System.out.println("LCM of 15 and 20: " + lcmCalc3.lcm(15, 20));
 }
}
