package GCDCalculator.java;

//Class to calculate LCM using GCD
public class LCMCalculator {
 private GCDCalculator gcdCalculator = new GCDCalculator(); // Instance of GCDCalculator

 public int lcm(int a, int b) {
     return (a * b) / gcdCalculator.gcd(a, b);
 }
}
