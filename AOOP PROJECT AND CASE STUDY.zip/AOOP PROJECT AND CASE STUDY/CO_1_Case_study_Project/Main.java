package SingletonExample.java;

public class Main {
    public static void main(String[] args) {
        // Getting the Singleton instance
        SingletonExample obj1 = SingletonExample.getInstance();
        obj1.showMessage();

        // Getting another reference to the same instance
        SingletonExample obj2 = SingletonExample.getInstance();
        obj2.showMessage();

        // Checking if both objects are the same
        System.out.println("Are obj1 and obj2 the same instance? " + (obj1 == obj2));
    }
}
