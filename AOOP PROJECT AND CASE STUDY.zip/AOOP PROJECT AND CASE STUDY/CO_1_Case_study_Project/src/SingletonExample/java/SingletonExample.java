package SingletonExample.java;

//Singleton Class
class SingletonExample {
 private static SingletonExample instance;

 // Private constructor to prevent instantiation
 private SingletonExample() {
     System.out.println("Singleton Instance Created!");
 }

 // Public method to provide access to the instance
 public static SingletonExample getInstance() {
     if (instance == null) {
         instance = new SingletonExample();
     }
     return instance;
 }

 // Sample method to demonstrate functionality
 public void showMessage() {
     System.out.println("Hello from Singleton!");
 }
}
