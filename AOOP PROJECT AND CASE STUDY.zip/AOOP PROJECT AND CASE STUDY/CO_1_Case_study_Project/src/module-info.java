/**
 * 
 */
/**
 * 
 */
module Case_study {
}